import { doc, getDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { COLLECTIONS } from './schema';

// P1–P2: every signed-in user needs a users/{uid} document so points can be
// added to it. Runs on every sign-in; only creates the document if missing.
export async function ensureUserProfile(user) {
  const ref = doc(db, COLLECTIONS.users, user.uid);
  const snap = await getDoc(ref);
  if (snap.exists()) return;
  await setDoc(ref, {
    name: user.displayName || 'UW Student',
    uwEmail: user.email,
    totalPoints: 0,
    createdAt: serverTimestamp(),
  });
}
