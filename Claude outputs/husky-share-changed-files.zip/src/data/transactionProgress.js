import { doc, getDoc, runTransaction, serverTimestamp } from 'firebase/firestore';
import { deleteObject, getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { db, storage } from '../firebase';
import { COLLECTIONS, LISTING_TYPES, PHOTO_KINDS, REQUEST_STATUS, TRANSACTION_STAGE } from './schema';

export const STAGES = [
  TRANSACTION_STAGE.approved,
  TRANSACTION_STAGE.pickup,
  TRANSACTION_STAGE.return,
  TRANSACTION_STAGE.received,
];

// P1, L8.1–L8.2, B8.1–B8.2, G5.1: points per completed transaction.
export const LENDER_POINTS = 10;
export const BORROWER_POINTS = 5;
export const GIVEAWAY_POINTS = 15;

export function confirmationId(requestId, kind, uid) {
  return `${requestId}_${kind}_${uid}`;
}

export function isParticipant(request, uid) {
  return request && (request.ownerId === uid || request.requesterId === uid);
}

export async function getTransaction(requestId, uid) {
  const snap = await getDoc(doc(db, COLLECTIONS.requests, requestId));
  if (!snap.exists()) throw new Error('Request not found.');
  const request = { id: snap.id, ...snap.data() };
  if (!isParticipant(request, uid) || request.status !== REQUEST_STATUS.approved) {
    throw new Error('This transaction is not available to your account.');
  }
  return request;
}

export async function confirmExchange(requestId, uid, kind, photo) {
  if (![PHOTO_KINDS.pickup, PHOTO_KINDS.return].includes(kind)) {
    throw new Error('Unknown confirmation type.');
  }
  if (!photo) throw new Error('Please upload a photo.');
  if (!photo.type.startsWith('image/') || photo.size > 10 * 1024 * 1024) {
    throw new Error('Please select an image smaller than 10 MB.');
  }
  const current = await getTransaction(requestId, uid);
  if (current.listingType !== LISTING_TYPES.lend) throw new Error('Only lending transactions use this confirmation.');
  const expectedStage = kind === PHOTO_KINDS.pickup ? TRANSACTION_STAGE.approved
    : uid === current.ownerId ? TRANSACTION_STAGE.return : TRANSACTION_STAGE.pickup;
  if ((current.stage || TRANSACTION_STAGE.approved) !== expectedStage) {
    throw new Error('This confirmation is not available at the current stage.');
  }
  const photoRef = ref(storage, `confirmationPhotos/${uid}/${requestId}/${kind}/${Date.now()}-${photo.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`);
  await uploadBytes(photoRef, photo, { contentType: photo.type });
  let photoUrl;
  try {
    photoUrl = await getDownloadURL(photoRef);
  } catch (cause) {
    await deleteObject(photoRef).catch(() => {});
    throw cause;
  }
  const requestRef = doc(db, COLLECTIONS.requests, requestId);
  const myRef = doc(db, COLLECTIONS.confirmationPhotos, confirmationId(requestId, kind, uid));
  const otherId = current.ownerId === uid ? current.requesterId : current.ownerId;
  const otherRef = doc(db, COLLECTIONS.confirmationPhotos, confirmationId(requestId, kind, otherId));
  const listingRef = doc(db, COLLECTIONS.listings, current.listingId);
  try {
    await runTransaction(db, async tx => {
      const isReceivingReturn = kind === PHOTO_KINDS.return && uid === current.ownerId;
      const reads = [tx.get(requestRef), tx.get(myRef), tx.get(otherRef)];
      if (isReceivingReturn) {
        reads.push(
          tx.get(listingRef),
          tx.get(doc(db, COLLECTIONS.users, current.ownerId)),
          tx.get(doc(db, COLLECTIONS.users, current.requesterId)),
        );
      }
      const [requestSnap, mine, theirs, listingSnap, ownerUserSnap, borrowerUserSnap] = await Promise.all(reads);
      if (!requestSnap.exists()) throw new Error('Request not found.');
      const request = requestSnap.data();
      if (!isParticipant(request, uid) || request.status !== REQUEST_STATUS.approved) throw new Error('Not allowed.');
      if ((request.stage || TRANSACTION_STAGE.approved) !== expectedStage) {
        throw new Error('This transaction has already moved to another stage.');
      }
      if (mine.exists()) throw new Error('You have already confirmed this exchange.');
      if (isReceivingReturn &&
          (!listingSnap?.exists() || listingSnap.data().ownerId !== uid ||
           listingSnap.data().status !== 'On Loan' || listingSnap.data().approvedRequestId !== requestId)) {
        throw new Error('The listing is not ready to become available again.');
      }
      if (isReceivingReturn && (!ownerUserSnap?.exists() || !borrowerUserSnap?.exists())) {
        throw new Error('A user profile is missing, so points cannot be awarded. Both people need to open Husky Share once while signed in, then try again.');
      }

      tx.set(myRef, { requestId, userId: uid, kind, photoUrl, createdAt: serverTimestamp() });
      if (kind === PHOTO_KINDS.pickup && theirs.exists()) {
        tx.update(requestRef, { stage: TRANSACTION_STAGE.pickup });
      }
      if (kind === PHOTO_KINDS.return && uid === request.requesterId) {
        tx.update(requestRef, { stage: TRANSACTION_STAGE.return });
      }
      if (isReceivingReturn) {
        // LS6 + P1/P2: receiving, reactivating, and awarding both users' points
        // are one atomic Firestore transaction. This works on the Spark plan.
        const ownerPoints = Number(ownerUserSnap.data().totalPoints) || 0;
        const borrowerPoints = Number(borrowerUserSnap.data().totalPoints) || 0;
        const ownerUserRef = doc(db, COLLECTIONS.users, request.ownerId);
        const borrowerUserRef = doc(db, COLLECTIONS.users, request.requesterId);
        const ownerPointsRef = doc(db, COLLECTIONS.pointsRecords, `${requestId}_${request.ownerId}`);
        const borrowerPointsRef = doc(db, COLLECTIONS.pointsRecords, `${requestId}_${request.requesterId}`);

        tx.update(requestRef, { stage: TRANSACTION_STAGE.received });
        tx.update(listingRef, { status: 'Active', approvedRequestId: null });
        tx.update(ownerUserRef, { totalPoints: ownerPoints + LENDER_POINTS, lastPointsRequestId: requestId });
        tx.update(borrowerUserRef, { totalPoints: borrowerPoints + BORROWER_POINTS, lastPointsRequestId: requestId });
        tx.set(ownerPointsRef, {
          requestId, userId: request.ownerId, points: LENDER_POINTS,
          reason: 'Completed borrowing transaction', createdAt: serverTimestamp(),
        });
        tx.set(borrowerPointsRef, {
          requestId, userId: request.requesterId, points: BORROWER_POINTS,
          reason: 'Completed borrowing transaction', createdAt: serverTimestamp(),
        });
      }
    });
  } catch (cause) {
    // A failed Firestore confirmation must not leave an unused upload behind.
    await deleteObject(photoRef).catch(() => {});
    throw cause;
  }
  return photoUrl;
}

// S6.7–S6.9, G4.8–G4.11: for selling, the buyer marks the item as picked up.
// For giving, the giver marks it. If anything fails, the stage stays the same.
// `save` lets the page cancel a slow save (same pattern as createListing):
// once save.aborted is true the transaction will not write.
export async function confirmSellGivePickup(requestId, uid, save = {}) {
  const requestRef = doc(db, COLLECTIONS.requests, requestId);
  // G5.1: a giveaway also awards the giver points, so read their profile too.
  const giverRef = doc(db, COLLECTIONS.users, uid);
  const giverPointsRef = doc(db, COLLECTIONS.pointsRecords, `${requestId}_${uid}`);
  await runTransaction(db, async tx => {
    const [snap, giverSnap] = await Promise.all([tx.get(requestRef), tx.get(giverRef)]);
    if (!snap.exists()) throw new Error('Request not found.');
    const request = snap.data();
    if (request.status !== REQUEST_STATUS.approved) throw new Error('This transaction is not approved.');
    let confirmerId = null;
    if (request.listingType === LISTING_TYPES.sell) confirmerId = request.requesterId;
    if (request.listingType === LISTING_TYPES.give) confirmerId = request.ownerId;
    if (confirmerId !== uid) throw new Error('Only the buyer or the giver can confirm this pickup.');
    if ((request.stage || TRANSACTION_STAGE.approved) !== TRANSACTION_STAGE.approved) {
      throw new Error('This item has already been picked up.');
    }
    const isGive = request.listingType === LISTING_TYPES.give;
    if (isGive && !giverSnap.exists()) {
      throw new Error('Your profile is not set up yet. Please refresh the page and try again.');
    }
    if (save.aborted) throw new Error('Saving was cancelled.');
    save.committing = true;
    tx.update(requestRef, { stage: TRANSACTION_STAGE.pickup });
    // G5.1–G5.2 + P3: giver gets 15 points exactly once. This only runs while
    // the stage is still Approved, and the rules refuse a second record with
    // the same requestId_uid id.
    if (isGive) {
      const giverPoints = Number(giverSnap.data().totalPoints) || 0;
      tx.update(giverRef, { totalPoints: giverPoints + GIVEAWAY_POINTS, lastPointsRequestId: requestId });
      tx.set(giverPointsRef, {
        requestId, userId: uid, points: GIVEAWAY_POINTS,
        reason: 'Completed giveaway transaction', createdAt: serverTimestamp(),
      });
    }
  });
}
