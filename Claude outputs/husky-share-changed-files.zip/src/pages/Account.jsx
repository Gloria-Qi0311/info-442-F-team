import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { doc, onSnapshot } from 'firebase/firestore';
import { useAuth } from '../auth/AuthContext';
import { useCurrentUser } from '../data/currentUser';
import { db } from '../firebase';
import { COLLECTIONS } from '../data/schema';

export default function Account() {
  const user = useCurrentUser();
  const { user: authUser, signOutUser } = useAuth();
  const navigate = useNavigate();
  const [totalPoints, setTotalPoints] = useState(null);

  // P4: show the user's current total points, updated live.
  useEffect(() => {
    if (!authUser) return undefined;
    return onSnapshot(
      doc(db, COLLECTIONS.users, authUser.uid),
      (snap) => setTotalPoints(snap.exists() ? Number(snap.data().totalPoints) || 0 : 0),
      () => setTotalPoints(null),
    );
  }, [authUser]);

  async function handleSignOut() {
    try {
      await signOutUser();
      navigate('/verify', { replace: true });
    } catch (error) {
      console.error('Could not sign out:', error);
    }
  }

  return (
    <main className="page">
      <h1>My Account</h1>
      <dl className="account-details">
        <dt>Name</dt>
        <dd>{user.name}</dd>
        <dt>UW email</dt>
        <dd>{user.uwEmail}</dd>
        <dt>Total points</dt>
        <dd>{totalPoints === null ? 'Loading...' : totalPoints}</dd>
      </dl>
      <button type="button" className="account-sign-out" onClick={handleSignOut}>
        Sign Out
      </button>
    </main>
  );
}
